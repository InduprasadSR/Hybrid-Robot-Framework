import pip

pip.main(['install', "xlrd"])
pip.main(['install', "selenium"])
pip.main(['install', "robotframework"])
pip.main(['install', "robotframework-selenium2library"])
pip.mail(['install','robotframework-angularjs'])
